from telegram import Bot

bot = Bot('7451785085:AAG3E1F_C86kyJ5f23ak0_3-CchGxPIUoig')

print(bot.set_webhook('https://a65f-213-206-61-87.ngrok-free.app/bot/'))